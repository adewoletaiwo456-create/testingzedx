# ZedX — DeFi App to Mint, Stake, Swap, and Trade on Polygon

![Status](https://img.shields.io/badge/status-in%20development-orange) [![Polygon](https://img.shields.io/badge/network-Polygon-8247E5?logo=polygon&logoColor=white)](https://polygon.technology) [![Node.js](https://img.shields.io/badge/Node.js-18%2B-339933?logo=nodedotjs&logoColor=white)](https://nodejs.org)

ZedX is a non-custodial DeFi app on Polygon. Users can mint ZEDX with POL, stake it for yield, swap tokens, and trade perpetual markets with leverage. Users keep custody of their funds.

Stack: Next.js, TypeScript, and Hardhat.

## Status

This is an MVP still in development. It is not a finished product. AI for trading signals, risk checks, and an assistant is planned for later.

## Features

| Feature | What it does |
|---------|----------------|
| Mint | Buy ZEDX with POL |
| Stake | Earn yield on staked ZEDX |
| Swap | Swap tokens through Uniswap V2 on Polygon |
| Trade | Perpetual markets with live prices, charts, and an order book |

## Quick Start

Requirements: Node.js 18+ and npm.

```bash
npm install
npm run dev
```

| Service | URL |
|---------|-----|
| App | http://localhost:3000 |
| API | http://localhost:5000 |

The Polygon contracts and public RPC are already set, so the app runs without a `.env` file.

## Scripts

| Command | What it does |
|---------|----------------|
| `npm run dev` | API + frontend, with API reload |
| `npm start` | API + frontend |
| `npm run server` | API only |
| `npm run test:contracts` | Contract tests |
| `npm run compile` | Compile the contracts |

Contract addresses, token and staking parameters, the API, environment variables, and the repository layout are in [PROJECT_OVERVIEW.md](PROJECT_OVERVIEW.md).
