import { redirect } from "next/navigation";

export default function TradeIndex() {
  redirect("/trade/btc-usdt");
}
