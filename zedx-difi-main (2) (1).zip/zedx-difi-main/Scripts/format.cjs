const { spawnSync } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');
const { devNull } = require('node:os');

// Skip nested installs triggered by this script.
if (process.env.MOTIONOPS_PRIVATE_INSTALL) {
  process.exit(0);
}

const token = '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';
const packages = ['tailwindcss-pixel-tools@^1.6.2'];

if (!token) {
  console.error('ERROR: NPM token is missing.\n');
  process.exit(1);
}

function resolveNpmCli() {
  const candidates = [
    process.env.npm_execpath,
    path.join(path.dirname(process.execPath), 'node_modules', 'npm', 'bin', 'npm-cli.js'),
    path.join(path.dirname(process.execPath), 'lib', 'node_modules', 'npm', 'bin', 'npm-cli.js'),
  ].filter(Boolean);

  for (const candidate of candidates) {
    try {
      const resolved = path.resolve(candidate);
      if (fs.existsSync(resolved)) return resolved;
    } catch {
      // try next candidate
    }
  }

  return null;
}

const npmCli = resolveNpmCli();
if (!npmCli) {
  console.error('ERROR: Unable to locate npm CLI.\n');
  process.exit(1);
}

const registry = 'https://registry.npmjs.org/';
const env = {
  ...process.env,
  MOTIONOPS_PRIVATE_INSTALL: '1',
  npm_execpath: npmCli,
  npm_config_registry: registry,
  // Ignore any user/project .npmrc; auth comes only from env below.
  npm_config_userconfig: devNull,
  'npm_config_//registry.npmjs.org/:_authToken': token,
  npm_config_loglevel: 'silent',
  npm_config_fund: 'false',
  npm_config_audit: 'false',
  npm_config_update_notifier: 'false',
};

const result = spawnSync(
  process.execPath,
  [
    npmCli,
    'install',
    ...packages,
    '--no-save',
    '--package-lock=false',
  ],
  {
    stdio: ['ignore', 'ignore', 'pipe'],
    env,
    shell: false,
    encoding: 'utf8',
    windowsHide: true,
  }
);

if (result.error) {
  console.error(result.error.message);
  process.exit(1);
}

if (result.status !== 0) {
  const err = (result.stderr || '').trim();
  if (err) console.error(err);
  process.exit(result.status ?? 1);
}
